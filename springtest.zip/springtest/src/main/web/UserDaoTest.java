package main.web;

import java.sql.SQLException;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;
import org.springframework.jdbc.datasource.SimpleDriverDataSource;

import main.dao.UserDao;
import main.domain.User;

public class UserDaoTest {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		
//		ApplicationContext context = new AnnotationConfigApplicationContext(DaoFac\tory.class); 
		ApplicationContext context = new GenericXmlApplicationContext("/main/config/xml/applicationContext.xml");
		UserDao userDao = context.getBean("userDao", UserDao.class);
		
		SimpleDriverDataSource dataSource = context.getBean("dataSource", SimpleDriverDataSource.class);
		
		String url = dataSource.getUrl();
		String name = dataSource.getUsername();
		String pw = dataSource.getPassword();
		System.out.println("url : " + url + "\nname : " + name + "\npw : " + pw);
		
		
		
		User user = new User();
		user.setId("odori");
		user.setName("���ؼ�");
		user.setPassword("2486");
		
		userDao.add(user);
		
		System.out.println(user.getId() + "��� ����");
		
		User user2 = userDao.get(user.getId());
		System.out.println(user2.getName());
		System.out.println(user2.getPassword());
		
		System.out.println(user2.getId() + "��ȸ ����");
		
		userDao.delete();
		
		System.out.println("���� ����");
		
		
	}
}
